import javax.swing.*;

public class FirstDialog {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello! H0w 4re y0u");
        System.exit(0);
    }
}
